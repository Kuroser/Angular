import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tienda',
  templateUrl: '../../vistas/zonaTienda/tienda.component.html',
  styleUrls: ['../../vistas/zonaTienda/css/tienda.component.css']
})
export class TiendaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
