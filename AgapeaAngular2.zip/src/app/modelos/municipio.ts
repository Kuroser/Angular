export interface IMunicipo {
    CodMun: number;
    CodPro: number;
    NombreMunicipio: number;
}