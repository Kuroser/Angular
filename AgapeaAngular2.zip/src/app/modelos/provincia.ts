export interface IProvincia {
    CodPro: number;
    NombreProvincia: string;
}