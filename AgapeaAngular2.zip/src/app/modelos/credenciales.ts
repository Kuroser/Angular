export interface ICredenciales {
    login: string;
    email: string;
    password?: string;
    imagenAvatar?: string;
    cuentaActiva: boolean;
}